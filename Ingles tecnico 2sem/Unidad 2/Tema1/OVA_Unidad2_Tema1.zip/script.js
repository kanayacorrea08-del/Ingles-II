const answers = {
  q1: "b",
  q2: "a",
  q3: "a",
};

const checkBtn = document.getElementById("checkBtn");
const result = document.getElementById("result");

checkBtn.addEventListener("click", () => {
  let score = 0;
  const total = Object.keys(answers).length;

  for (const [question, correct] of Object.entries(answers)) {
    const selected = document.querySelector(`input[name="${question}"]:checked`);
    if (selected && selected.value === correct) {
      score += 1;
    }
  }

  const percentage = Math.round((score / total) * 100);
  const passed = percentage >= 70;

  result.className = `result ${passed ? "ok" : "warn"}`;
  result.textContent = passed
    ? `Resultado: ${score}/${total} (${percentage}%). Excelente, has alcanzado el objetivo.`
    : `Resultado: ${score}/${total} (${percentage}%). Revisa el contenido e inténtalo de nuevo.`;
});
